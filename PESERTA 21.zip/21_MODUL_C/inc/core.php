<?php

include "session.php";
include "database.php";
include "input.php";
include "helper.php";

function auth($role="admin|user"){
	$role = explode("|", $role);
	$session = $GLOBALS['session'];
	if(in_array($session->get('role'), $role)){
		return TRUE;
	}
	else{
		die("Anda tidak berhak mengakses menu ini");
	}
}

$base_url = 'http://localhost/';