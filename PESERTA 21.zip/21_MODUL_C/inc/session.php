<?php

session_start();

class Session{

	function set($key, $value=NULL){
		$_SESSION[$key] = $value;

		return TRUE;
	}

	function get($key){
		return isset($_SESSION[$key]) ? $_SESSION[$key] : NULL;
	}

	function destroy(){
		return session_destroy();
	}
}

$session = new Session();