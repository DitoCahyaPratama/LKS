<?php

class Database{

	public $hostname;
	public $username;
	public $password;
	public $database;
	public $koneksi;

	function __construct(){
		$this->hostname = "localhost";
		$this->username = "root";
		$this->password = "";
		$this->database = "geekbot";
		$this->koneksi = mysqli_connect(
			$this->hostname,
			$this->username,
			$this->password,
			$this->database
		) or die("Tidak terhubung dengan basis data");
	}

	function query($query){
		$result = mysqli_query($this->koneksi, $query);

		if($result){
			return $result;
		}
		else{
			die(mysqli_error($this->koneksi));
		}
	}

	function select($query){
		$result = $this->query($query);
		$data = array();
		while($row = mysqli_fetch_object($result)){
			$data[] = $row;
		}

		return $data;
	}

	function select_row($query){
		$result = $this->query($query);
		$data = NULL;
		if($row = mysqli_fetch_object($result)){
			$data = $row;
		}

		return $data;
	}

	function update($query){
		$result = $this->query($query);
		return mysqli_affected_rows($this->koneksi);
	}

	function delete($query){
		$result = $this->query($query);
		return mysqli_affected_rows($this->koneksi);
	}

	function insert($query){
		$result = $this->query($query);
		return mysqli_insert_id($this->koneksi);
	}

	function escape($str){
		return mysqli_real_escape_string($this->koneksi, $str);
	}
}

$db = new Database();