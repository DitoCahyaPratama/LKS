<?php

function dump($data){
	echo "<pre>";
	var_dump($data);
	echo "</pre>";
}

function idr($money){
	return "Rp. ".str_replace(',', '.', number_format($money));
}

function redirect($file){
	header('Location: '.$file);
}

date_default_timezone_set("Asia/Jakarta");