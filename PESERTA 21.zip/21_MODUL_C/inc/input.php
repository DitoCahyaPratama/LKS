<?php

class Input{

	function get($index, $escape=FALSE){
		if(isset($_GET[$index])){
			if($escape === TRUE){
				$db = $GLOBALS['db'];

				return $db->escape($_GET[$index]);
			}
			else{
				return $_GET[$index];
			}
		}
		else{
			return NULL;
		}
	}

	function post($index, $escape=FALSE){
		if(isset($_POST[$index])){
			if($escape === TRUE){
				$db = $GLOBALS['db'];

				return $db->escape($_POST[$index]);
			}
			else{
				return $_POST[$index];
			}
		}
		else{
			return NULL;
		}
	}

}

$input = new Input();