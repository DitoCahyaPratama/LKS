<?php 
	
	require "inc/core.php";

	if(auth('user')){
		$cart = $session->get('cart');
		$date = date('Y-m-d');
		$sql = "INSERT INTO `order`(`idOrder`, `orderDate`, `idCustomer`, `idKirim`) VALUES ('','{$date}','{$session->get('id')}','{$cart['idKirim']}')";

		$idOrder = $db->insert($sql);

		$sql = array();

		foreach ($cart['product'] as $idProduk => $amount) {
			if($amount > 0){
				$produk = $db->select_row("SELECT * FROM `produk` LEFT JOIN `kategori` ON `kategori`.`idKategori` = `produk`.`idKategori` WHERE `idProduk` = '{$db->escape($idProduk)}'");
				$total = $amount*$produk->hargaProduk;
				$sql[] = "(NULL,'{$amount}','{$total}','{$idOrder}','{$idProduk}')";
			}
		}

		$sql = "INSERT INTO `orderdetail`(`idOrderDetail`, `jumlahBarang`, `totalHarga`, `idOrder`, `idProduk`) VALUES ".implode(", ", $sql);
		$db->insert($sql);

		redirect('history.php');
	}
	else{
		redirect('login.php');
	}

?>