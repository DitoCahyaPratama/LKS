

	'use strict';

	var produk = {
		list: [],
		paket : 0
	}

	$('[data-price]').change(function(){
		var money = $(this).val() * $(this).data('price');

		$(this).siblings('.price').text(toIdr(money));
		produk.list[$(this).data('id')] = money;
		refreshTotal();
	});

	$('select[name="idKirim"]').change(function(){
		var idKirim = $(this).val();
		var paket = $paket.find(function(p){
			return p.idKirim == idKirim;
		});

		$('#hargaPaket').text(toIdr(parseInt(paket.hargaPaket)));
		produk.paket = parseInt(paket.hargaPaket);
		refreshTotal();
	});

	function refreshTotal(){
		var total = 0;
		total += produk.paket;
		produk.list.forEach(function(p){
			total += p;
		});

		$('#total').text(toIdr(total));
	}

	function toIdr(str){
		str = str.toString();
		var money = str.split("").reverse();
		var newMoney = [];
		for(var i=0;i<money.length;i++){
			if(i%3==0 && i!=0){
				newMoney.push(".");
			}
			newMoney.push(money[i]);
		}
		return "Rp. "+newMoney.reverse().join("");
	}