<?php

	require "inc/core.php";

	if(auth('user')){
		$order = $db->select("SELECT * FROM `order` LEFT JOIN `kirim` ON `kirim`.`idKirim` = `order`.`idKirim` WHERE `idCustomer` = '{$session->get('id')}'");

		foreach($order as $k => $o){
			$order[$k]->list = $db->select("SELECT * FROM `orderdetail` LEFT JOIN `produk` ON `orderdetail`.`idProduk` = `produk`.`idProduk` WHERE `idOrder` = '{$o->idOrder}'");
		}
	}
	else{
		redirect('login');
		exit;
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Geekbot List Produk</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/app.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<?php include "header.php" ?>

	<div class="background">
		<div class="container bg-white">
			<h3><?= $session->get('nama') ?></h3>
			<br>
			<h3>Shopping History</h3>

			<div class="shop-box">
				<?php foreach($order as $o){ ?>
				<div style="border: 1px solid #000;">
					<h3><?= $o->orderDate ?> - <?= $o->namaPaket ?> : <?= intval($o->hargaPaket) ?></h3>
					<h5>Order detail</h5>
					<?php $total = $o->hargaPaket ?>
					<table class="table">
						<thead>
							<tr>
								<th>ID</th>
								<th>Nama</th>
								<th>Jumlah</th>
								<th>Harga</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($o->list as $d){ ?>
							<tr>
								<td><?= $d->idProduk ?></td>
								<td><?= $d->namaProduk ?></td>
								<td><?= $d->jumlahBarang ?></td>
								<td><?= intval($d->totalHarga / $d->jumlahBarang) ?></td>
							</tr>
							<?php $total+=$d->totalHarga;} ?>
						</tbody>
					</table>
					<h3>Harga Total : <?= $total ?></h3>
				</div>
				<?php } ?>
			</div>
		</div>
	</div>

	<script type="text/javascript" src="js/jquery-3.1.0.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>