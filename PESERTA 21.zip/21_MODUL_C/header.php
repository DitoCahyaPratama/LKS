<header>
	<nav class="navbar text-white">
		<div class="container">
			<div class="navbar-header">
				<a class="navbar-brand" href="#" style="color: white;">GEEKBOT</a>
			</div>
			<ul class="nav navbar-nav navbar-right">
				<?php if($session->get('valid') === TRUE){ ?>
				<li><a href="<?= $base_url ?>history.php"><?= $session->get('nama') ?></a></li>
				<li><a href="<?= $base_url ?>logout.php">Logout</a></li>
				<?php }else{ ?>
				<li><a href="<?= $base_url ?>login.php">Log In</a></li>
				<li><a href="<?= $base_url ?>register.php">Register</a></li>
				<?php } ?>
			</ul>
		</div>
	</nav>
</header>