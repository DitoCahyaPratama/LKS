<?php

	require "inc/core.php";

	if(isset($_POST['submit'])){
		$nama = $input->post('nama', TRUE);
		$noHP = $input->post('noHP', TRUE);
		$alamat = $input->post('alamat', TRUE);
		$email = $input->post('email', TRUE);
		$password = password_hash($input->post('password'), PASSWORD_DEFAULT);

		$sql = "INSERT INTO `customer`(`idCustomer`, `nama`, `alamat`, `noHP`, `password`, `email`, `role`) VALUES (NULL,'{$nama}','{$alamat}','{$noHP}','{$password}','{$email}','user')";
		$user = $db->query($sql);
		if($user){
			redirect('login.php');
		}
		else{
			die('Gagal Register');
		}
		exit;
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/app.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body class="login">

	<div class="row">
		<div class="col-sm-3">
			<div class="bar text-white" style="padding-left: 30px">
				<br><br>
				<h3>Geek Bot</h3>
				<h4>Register</h4>
			</div>
		</div>
		<div class="col-sm-3">
			<form class="form-style text-center" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
				<h3>Register</h3>
				<img src="images/login.png" class="img-responsive">
				<div class="form-group">
					<label>Nama</label>
					<input type="text" name="nama">
				</div>
				<div class="form-group">
					<label>Email</label>
					<input type="email" name="email">
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="password">
				</div>
				<div class="form-group">
					<label>No HP</label>
					<input type="text" name="noHP">
				</div>
				<div class="form-group">
					<label>Alamat Rumah</label>
					<input type="text" name="alamat">
				</div>
				<input type="submit" name="submit" value="Register">
			</form>
		</div>
	</div>

	<script type="text/javascript" src="js/jquery-3.1.0.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>