<?php

require "../inc/core.php";
if(!auth('admin')){
	die('Unauthorized');
}

$id = $input->get('id', TRUE);
$produk = $db->select_row("SELECT * FROM `produk` WHERE `idProduk` = '{$id}'");

if(!empty($produk)){
	$db->delete("DELETE FROM `produk` WHERE `idProduk` = '{$id}'");
	redirect('index.php');
}
else{
	die('Produk tidak ditemukan');
}