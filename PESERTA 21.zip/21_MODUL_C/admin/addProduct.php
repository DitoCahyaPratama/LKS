<?php

require "../inc/core.php";
if(!auth('admin')){
	die('Unauthorized');
}

$kategori = $db->select("SELECT * FROM `kategori`");

if(isset($_POST['submit'])){
	$idProduk = $input->post('idProduk', TRUE);
	$namaProduk = $input->post('namaProduk', TRUE);
	$beratProduk = $input->post('beratProduk', TRUE);
	$warnaProduk = $input->post('warnaProduk', TRUE);
	$tanggalProduksi = $input->post('tanggalProduksi', TRUE);
	$hargaProduk = $input->post('hargaProduk', TRUE);
	$idKategori = $input->post('idKategori', TRUE);
	

	$sql = "INSERT INTO `produk`(`idProduk`, `namaProduk`, `beratProduk`, `warnaProduk`, `tanggalProduksi`, `hargaProduk`, `idKategori`) VALUES ('{$idProduk}','{$namaProduk}','{$beratProduk}','{$warnaProduk}','{$tanggalProduksi}','{$hargaProduk}','{$idKategori}')";
	$db->insert($sql);
	redirect('index.php');
	exit;
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Geekbot Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/app.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>

	<?php include "../header.php" ?>

	<div class="background">
		<div class="container bg-white">
			<h3>Add Product</h3>

			<form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
				<div class="form-group">
					<label>ID Produk</label>
					<input type="text" name="idProduk" class="form-control">
				</div>
				<div class="form-group">
					<label>Nama Produk</label>
					<input type="text" name="namaProduk" class="form-control">
				</div>
				<div class="form-group">
					<label>Berat Produk</label>
					<input type="text" name="beratProduk" class="form-control">
				</div>
				<div class="form-group">
					<label>Warna Produk</label>
					<input type="text" name="warnaProduk" class="form-control">
				</div>
				<div class="form-group">
					<label>Tanggal Produksi</label>
					<input type="date" name="tanggalProduksi" class="form-control">
				</div>
				<div class="form-group">
					<label>Harga Produk</label>
					<input type="number" name="hargaProduk" class="form-control" min="0" value="0">
				</div>
				<div class="form-group">
					<label>Kategori</label>
					<select name="idKategori" class="form-control">
						<?php foreach($kategori as $k){ ?>
						<option value="<?= $k->idKategori ?>"><?= $k->namaKategori ?></option>
						<?php } ?>
					</select>
				</div>
				<button type="submit" class="btn btn-primary" name="submit">Simpan</button>
			</form>
		</div>
	</div>

	<script type="text/javascript" src="../js/jquery-3.1.0.js"></script>
	<script type="text/javascript" src="../js/bootstrap.js"></script>
	<script type="text/javascript" src="../js/app.js"></script>
</body>
</html>