<?php

require "../inc/core.php";
if(!auth('admin')){
	die('Unauthorized');
}

$produk = $db->select("SELECT * FROM `produk` LEFT JOIN `kategori` ON `kategori`.`idKategori` = `produk`.`idKategori`");
$kategori = $db->select("SELECT * FROM `kategori`");

?>

<!DOCTYPE html>
<html>
<head>
	<title>Geekbot Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/app.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>

	<?php include "../header.php" ?>

	<div class="background">
		<div class="container bg-white">
			<h3>Product</h3>
			<a href="addProduct.php" class="btn btn-primary">Add Product</a>

			<table class="table">
				<thead>
					<tr>
						<th>Id</th>
						<th>Nama</th>
						<th>Berat</th>
						<th>Warna</th>
						<th>Tanggal Produksi</th>
						<th>Harga Produk</th>
						<th>Kategori</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($produk as $p){ ?>
					<tr>
						<td><?= $p->idProduk ?></td>
						<td><?= $p->namaProduk ?></td>
						<td><?= $p->beratProduk ?></td>
						<td><?= $p->warnaProduk ?></td>
						<td><?= $p->tanggalProduksi ?></td>
						<td><?= intval($p->hargaProduk) ?></td>
						<td><?= $p->namaKategori ?></td>
						<td>
							<a href="editProduct.php?id=<?= $p->idProduk ?>" class="btn btn-success">Edit</a>
							<a href="deleteProduct.php?id=<?= $p->idProduk ?>" class="btn btn-danger">Delete</a>
						</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>

			<br><br>
			<h3>Kategori</h3>
			<a href="addKategori.php" class="btn btn-primary">Add Kategori</a><br><br>

			<table class="table">
				<tbody>
					<?php foreach($kategori as $k){ ?>
					<tr>
						<td><?= $k->namaKategori ?></td>
						<td>
							<a href="deleteKategori.php?id=<?= $k->idKategori ?>" class="btn btn-danger">Delete</a>
						</td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>

	<script type="text/javascript" src="../js/jquery-3.1.0.js"></script>
	<script type="text/javascript" src="../js/bootstrap.js"></script>
	<script type="text/javascript" src="../js/app.js"></script>
</body>
</html>