<?php

require "../inc/core.php";
if(!auth('admin')){
	die('Unauthorized');
}

$id = $input->get('id', TRUE);
$kategori = $db->select_row("SELECT * FROM `kategori` WHERE `idKategori` = '{$id}'");

if(!empty($kategori)){
	$db->delete("DELETE FROM `kategori` WHERE `idKategori` = '{$id}'");
	redirect('index.php');
}
else{
	die('Kategori tidak ditemukan');
}