<?php

require "../inc/core.php";
if(!auth('admin')){
	die('Unauthorized');
}

if(isset($_POST['submit'])){
	$namaKategori = $input->post('namaKategori', TRUE);
	$db->insert("INSERT INTO `kategori`(`idKategori`, `namaKategori`) VALUES (NULL,'{$namaKategori}')");
	redirect('index.php');
	exit;
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Geekbot Admin</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/app.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>

	<?php include "../header.php" ?>

	<div class="background">
		<div class="container bg-white">
			<h3>Add Kategori</h3>
			<br>

			<form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
				<div class="form-group">
					<label>Nama Kategori</label>
					<input type="text" name="namaKategori" class="form-control">
				</div>

				<button type="submit" name="submit" class="btn btn-primary">Simpan</button>
			</form>

			<br>
		</div>
	</div>

	<script type="text/javascript" src="../js/jquery-3.1.0.js"></script>
	<script type="text/javascript" src="../js/bootstrap.js"></script>
	<script type="text/javascript" src="../js/app.js"></script>
</body>
</html>