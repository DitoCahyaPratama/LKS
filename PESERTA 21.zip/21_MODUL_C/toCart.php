<?php 
	
	require "inc/core.php";

	if(is_array($input->post('product')) && !empty($input->post('idKirim'))){
		$cart = array(
			'product' => $input->post('product'),
			'idKirim' => $input->post('idKirim')
		);

		$session->set('cart', $cart);

		redirect('cart.php');
	}
	else{
		die('INVALID');
	}

?>