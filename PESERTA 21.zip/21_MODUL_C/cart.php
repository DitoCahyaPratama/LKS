<?php

	require "inc/core.php";
	
	$cart = $session->get('cart');
	$produk = array();

	$i = 0;
	$total = 0;
	foreach($cart['product'] as $id => $amount){
		if($amount > 0){
			$produk[$i] = $db->select_row("SELECT * FROM `produk` LEFT JOIN `kategori` ON `kategori`.`idKategori` = `produk`.`idKategori` WHERE `idProduk` = '{$db->escape($id)}'");
			$produk[$i]->amount = $amount;
			$produk[$i]->total = $amount * $produk[$i]->hargaProduk;

			$total += $produk[$i]->total;
			$i++;
		}
	}

	$paket = $db->select_row("SELECT * FROM `kirim` WHERE `idKirim` = '{$db->escape($cart['idKirim'])}'");
	$total += $paket->hargaPaket;
?>

<!DOCTYPE html>
<html>
<head>
	<title>Geekbot List Produk</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/app.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<?php include "header.php" ?>

	<div class="background">
		<div class="container bg-white">
			<h3>Geek Bot Cart</h3>
			<div class="shop-box">
				<ul class="shop-list">
					<?php foreach($produk as $p){ ?>
					<li>
						<div class="row">
							<div class="col-sm-4">
								<h3><?= $p->idProduk ?> -  <?= $p->namaProduk ?></h3>
								<p><?= $p->beratProduk ?> (berat) / <?= $p->warnaProduk ?> / <?= $p->tanggalProduksi ?></p>
							</div>
							<div class="col-sm-4">
								<h3>@<?= idr($p->hargaProduk) ?></h3>
								<h4><?= $p->namaKategori ?></h4>
							</div>
							<div class="col-sm-4">
								<input type="number" min="0" value="<?= $p->amount ?>" readonly>
								<p class="price"><?= $p->total ?></p>
							</div>
						</div>
					</li>
					<?php } ?>
				</ul>
			</div>
			<div class="paketPengiriman">
				<h3>Pilih Pengiriman</h3>
				<div class="form-inline">
					<label>Pilih Paket : </label>
					<select name="idKirim" readonly>
						<option value="<?= $paket->idKirim ?>"><?= $paket->namaPaket ?></option>
					</select>
				</div>
				<h4 class="text-right" id="hargaPaket"><?= idr($paket->hargaPaket) ?></h4>
				<br>
			</div>
			<div>
				<h3 class="text-right">Total Harga: <span id="total"><?= idr($total) ?></span></h3>
			</div>
			<?php if($session->get('valid') == TRUE){ ?>
			<a href="process.php" class="btn btn-success center-block">Process</a>
			<?php }else{ ?>
			<a href="login.php" class="btn btn-danger center-block">kamu harus login</a>
			<?php } ?>
			<br>
		</div>
	</div>

	<script type="text/javascript">
		$paket = <?= json_encode($paket) ?>;
	</script>
	<script type="text/javascript" src="js/jquery-3.1.0.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>