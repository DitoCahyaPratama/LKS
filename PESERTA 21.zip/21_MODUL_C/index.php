<?php

	require "inc/core.php";
	$produk = $db->select("SELECT * FROM `produk` LEFT JOIN `kategori` ON `kategori`.`idKategori` = `produk`.`idKategori`");
	$paket = $db->select("SELECT * FROM `kirim`");
?>

<!DOCTYPE html>
<html>
<head>
	<title>Geekbot List Produk</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/app.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

	<?php include "header.php" ?>

	<div class="jumbotron">
		<div class="container">
			<h1>Welcome to Geek Bot!</h1>
			<h5>Check Out our latest product that might be what you need for your next project in our product gallery</h5>
		</div>
	</div>

	<div class="background">
		<div class="container bg-white">
			<h3>Geek Bot Shop</h3>
			<form action="toCart.php" method="post" class="">
				<div class="shop-box">
					<ul class="shop-list">
						<?php foreach($produk as $p){ ?>
						<li>
							<div class="row">
								<div class="col-sm-4">
									<h3><?= $p->idProduk ?> -  <?= $p->namaProduk ?></h3>
									<p><?= $p->beratProduk ?> (berat) / <?= $p->warnaProduk ?> / <?= $p->tanggalProduksi ?></p>
								</div>
								<div class="col-sm-4">
									<h3>@<?= idr($p->hargaProduk) ?></h3>
									<h4><?= $p->namaKategori ?></h4>
								</div>
								<div class="col-sm-4">
									<input type="number" name="product[<?= $p->idProduk ?>]" data-price="<?= $p->hargaProduk ?>" data-id="<?= $p->idProduk ?>" min="0" value="0">
									<p class="price">Rp. 0</p>
								</div>
							</div>
						</li>
						<?php } ?>
					</ul>
				</div>
				<div class="paketPengiriman">
					<h3>Pilih Pengiriman</h3>
					<div class="form-inline">
						<label>Pilih Paket : </label>
						<select name="idKirim">
							<?php foreach($paket as $p){ ?>
							<option value="<?= $p->idKirim ?>"><?= $p->namaPaket ?></option>
							<?php } ?>
						</select>
					</div>
					<h4 class="text-right" id="hargaPaket">Rp. 0</h4>
					<br>
				</div>
				<div>
					<h3 class="text-right">Total Harga: <span id="total">Rp. 0</span></h3>
				</div>
				<button class="btn btn-success center-block" type="submit">Submit</button>
				<br>
			</form>
		</div>
	</div>

	<script type="text/javascript">
		$paket = <?= json_encode($paket) ?>;
	</script>
	<script type="text/javascript" src="js/jquery-3.1.0.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>