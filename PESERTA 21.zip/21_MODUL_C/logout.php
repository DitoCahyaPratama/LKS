<?php

require "inc/core.php";
$session->destroy();
redirect('index.php');

?>