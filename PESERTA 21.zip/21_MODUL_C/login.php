<?php

	require "inc/core.php";

	if(isset($_POST['submit'])){
		$email = $input->post('email', TRUE);
		$password = $input->post('password');

		$sql = "SELECT * FROM `customer` WHERE `email` = '{$email}'";
		$user = $db->select_row($sql);
		if(!empty($user)){
			if(password_verify($password, $user->password)){
				$session->set('id', $user->idCustomer);
				$session->set('nama', $user->nama);
				$session->set('role', $user->role);
				$session->set('email', $user->email);
				$session->set('valid', TRUE);

				if($user->role === 'admin'){
					redirect('admin/index.php');
				}
				else{
					if(empty($session->get('cart'))){
						redirect('index.php');
					}
					else{
						redirect('cart.php');
					}
				}
			}
			else{
				die('Password salah');
			}
		}
		else{
			die('Akun tidak ditemukan');
		}
		exit;
	}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/app.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body class="login">

	<div class="row">
		<div class="col-sm-3">
			<div class="bar text-white" style="padding-left: 30px">
				<br><br>
				<h3>Geek Bot</h3>
				<h4>Log In</h4>
			</div>
		</div>
		<div class="col-sm-3">
			<form class="form-style text-center" action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
				<h3>Log In</h3>
				<img src="images/login.png" class="img-responsive">
				<div class="form-group">
					<label>Email</label>
					<input type="email" name="email">
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="password">
				</div>
				<input type="submit" name="submit" value="Log In">
			</form>
		</div>
	</div>

	<script type="text/javascript" src="js/jquery-3.1.0.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/app.js"></script>
</body>
</html>