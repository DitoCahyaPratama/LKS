(function($){

	'use strict';

	$(document).scroll(function(e){
		var scroll = $(this).scrollTop();
		var height = $(window).height();
		var navbar = $('.navbar');
		if(scroll >= height){
			navbar.addClass('bg-dark');
			navbar.removeClass('bg-transparent');
		}
		else{
			navbar.addClass('bg-transparent');
			navbar.removeClass('bg-dark');
		}
	});

	$('.navbar a[href^="#"], #home .carousel-overlay a[href^="#"]').click(function(event){
		event.preventDefault();
		var top = Math.ceil($($(this).attr('href')).offset().top - $('.navbar').height());
		$(document).scrollTop(top);
	});

	$(document).ready(function(){
	});

	$('.closeSidebar').click(function(){
		$('.navbar-collapse').collapse("hide");
	});

	$('.btn-featured').click(function(event){
		var index = $(this).closest('.card').parent().index() - 1;
		var product = data.featured[index];
		var modal = $('#featuredModal');
		
		modal.find('img').attr('src', product.img);
		modal.find('.title').text(product.title);
		modal.find('.description').text(product.description);

		modal.modal('show');
	});

	$('#productSlider .close').click(function(){
		$('#productSlider').fadeOut();
	});

	$('#listProduct button').click(function(){
		var index = $(this).closest('.card').parent().index() - 1;
		$('#productSlider .carousel').carousel(index);
		$('#productSlider').fadeIn();
	});

	$('#filterProduct a').click(function(event){
		event.preventDefault();

		var product = {
			all: [0,1,2,3,4,5,6,7,8,9,10,11],
			humanoid: [0,1,2],
			lego: [3,4,5,6,7,8],
			industrial: [9,10],
			transportation: [11]
		}
		var type = $(this).data('filter');
		var list = product[type];

		$('#filterProduct a').addClass('text-secondary').removeClass('text-primary');
		$(this).addClass('text-primary').removeClass('text-secondary');
		var data = $('#listProduct > div').not(':first').hide();

		list.forEach(function(i){
			data.eq(i).show();
		});
	});

	var data = {
		featured: [
			{
				img: 'img/featured/big/1.png',
				title: 'NEO ROBOT',
				description: 'Neo Robot is a robot made in 2016 that can move like human.'
			},
			{
				img: 'img/featured/big/2.png',
				title: 'LEGO ROBOT',
				description: 'LEGO Robot can be used for highly interactive teaching and learning process for beginner.'
			},
			{
				img: 'img/featured/big/3.png',
				title: 'BTK10',
				description: 'BTK10 is an industrial robot that can do some work in a factory.'
			},
			{
				img: 'img/featured/big/4.png',
				title: 'C-WHEEL',
				description: 'C-Wheel is our most recent product, this robot is intended transporting items, this robot is equipped with auto drive feature.'
			},
		]
	};

}(jQuery));